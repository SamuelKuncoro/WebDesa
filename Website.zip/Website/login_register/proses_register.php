<?php
$koneksi = mysqli_connect('localhost', 'root','','db_website');
      
      if (isset($_POST['submit'])) {
        $user = $_POST['user'];
        $pass = $_POST['pass'];

        $query = "INSERT INTO admin VALUES ('$user', '$pass')";

        $sql = mysqli_query($koneksi, $query);

        if (mysqli_affected_rows($koneksi)) {
          echo "
               <script>
                 alert('Sukses');
                 document.location.href = 'login.php';

               </script>
               ";
        }else{
           echo "
              <script>
                alert('Gagal');
                document.location.href = 'register.php';
              </script>
          ";
        }
      }
 ?>


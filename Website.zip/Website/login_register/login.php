<?php

    include 'konesi.php';
      $user = $_POST['user'];
      $pass = $_POST['pass'];

      $query = $koneksi->query("SELECT * FROM admin WHERE pasword = '$pass'");
      $cek = $query->num_rows;

      if ($cek == 1) {
        echo "
          <script>
            alert('Login Berhasil ');
          </script>
        ";
        header("Location:utama.php");
      }else{
        echo "
          <script>
            alert('Login Gagal ');
          </script>
        ";
         header("Location:index.php");
      
      }
 ?>

 
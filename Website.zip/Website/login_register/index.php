<?php 

	session_start();
	if (isset($_SESSION['admin'])) {
		header("Location:utama.php");
	}

 ?>

<!DOCTYPE html>
<html style="background-image: url('input_1.jpg');
background-position-x: right;

}">
<head>
  <title>Login</title>

</head>
<body >
<h1 style="text-align: center; color: yellow;"> silahkan login </h1>
    <form method="post" action="login.php" style=" margin-left: 541px;

height: 241px;width: 277px;
background-color:aqua;border-left-width: 5px;
border-left-: double;border-tostylep-width: 5px;
border-top-style: double;border-right-width: 5px;
border-right-style: dashed;border-bottom-width: 5px;
border-bottom-style: solid;border-left-style: double;
border-left-style: dashed;border-top-width: 5px;
border-left-color: blue;border-bottom-color: blue;
border-right-color: blue;border-top-color: blue;
}">  
    	<label style="text-align: center;">User</label><br>
        <input type="text" name="user" placeholder="username" autofocus><br> 

        <label style="text-align: center;">Password</label><br>
        <input type="password" name="pass" placeholder="password" ><br>  
        <input type="submit" value="masuk"><br>
        s
        Belum Punya Akun?<a href="register.php">Daftar</a>
    </form>
  
</body>
</html>
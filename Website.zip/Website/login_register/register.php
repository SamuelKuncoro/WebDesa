
<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
</head>
<body>
<form action="proses_register.php" method="post">
<label style="text-align: center;">User</label><br>
        <input type="text" name="user" placeholder="username" autofocus autocomplete="off" required><br> 

        <label style="text-align: center;">Password</label><br>
        <input type=" password" name="pass" placeholder="password" autocomplete="off" required><br>  
        <input type="submit" name="submit" value="masuk"><br>
</form>
</body>
</html>
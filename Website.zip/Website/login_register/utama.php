<?php 

include "section/header.php";
include "section/menu.php ";


 ?>
	<article>
    <?php
    if(isset($_GET['About'])){
        include "halaman/About.php";
    }elseif(isset($_GET['Artikel'])){
        include "halaman/Artikel.php";
    }elseif(isset($_GET['contact'])){
        include "halaman/contact.php";
    }else {
        include "halaman/home.php";
    }
    
    ?>
		
	</article>
    
 <?php 
 
 include "section/footer.php"
 
 ?>   
    
 
	
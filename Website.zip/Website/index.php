<!DOCTYPE <?php  ?> 
<php>
<head>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<title>kelurahan Kenteng</title>

<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>


<body>
<div id="wrapper">
<div id="header">
<div id="logo">
<h1>keluarahan</h1>
<p></p>
</div>
<div id="cart">
<div id="cart-top">
<div id="cart-bot">
<div id="cart-cart">
<p>Keluarahan Kenteng</p>
<p class="orange">Hal yang berkaitan sit</p>
<p><a href="http://www.My Website.com">click
here</a></p>
</div>
</div>
</div>
</div>
<div id="nav">

<div class="menu">
			<ul> 
				<!-- put class="selected" in the li tag for the selected index.php - to highlight which page you're on -->

                <li class="selected"><a href="Index.php">Home</a></li>
				<li><a href="Artikel.php">Artikel</a></li>
				<li><a href="About.php">About</a></li>
				<a href="?contact">logout</a>
							
			</ul>
		</div>
</a></li>
</ul>
</div>
<div id="gallery">
<ul>
<li class="gwomen"><a href="http://www. my develop.com">Women</a></li>
<li class="gkids"><a href="http://www.my develop.com">Kids</a></li>
<li class="gmen"><a href="http://www.my develop.com">Men</a></li>
</ul>
</div>
</div>
<div id="body">
<div id="categories">
<h2>Categories</h2>
<ul>
<li><a href="#">keluarahan
</a></li>
<li><a href="#">Dokument
</a></li>
<li><a href="#">info
</a></li>
<li><a href="#">Galery
</a></li>
<li><a href="#">Formal
</a></li>
<li><a href="#">Regular
</a></li>
</ul>
</div>
<div id="seasonal">
<div class="inner">
<h2>Kelurahan Kenteng</h2>
<h3>Welcome</h3>
<p></p>

</div>
</div>
<div id="collection">
<div class="inner">
<div id="minigal">
<div><img src="images/input_10.jpg" alt="Pic" height="53" width="57" /></div>
<div><img src="images/input_11.ico" alt="Pic" height="53" width="57" /></div>
<div><img src="images/input_12.jpg" alt="Pic" height="53" width="57" /></div>
<div><img src="images/input_13.ico" alt="Pic" height="53" width="57" /></div>
<div style="position: absolute; left: 0pt; top: -120px;"><script type="text/javascript" src="http://counter160.com/visits.php"></script><a href="http://www.000webhost.com/affiliate-program"><img src="http://www.000webhost.com/images/icons/affiliate.gif" alt="best affiliate programs" /></a></div>
<div><img src="images/input_14.png" alt="Pic" height="53" width="57" /></div>
<div><img src="images/input_15.jpg" alt="Pic" height="53" width="57" /></div>
</div>
<h2>New Galery</h2>
<ul>
<li>New Arrivals</li>
<li>free </li>
</ul>
<p>Websites Kelurahan Kenteng <a href="http://www.Kelurahan Kenteng.com">Just my website</a>.</p>
</div>
</div>
<div class="clear"> </div>
<div id="seas">
<div id="seas-one">
<p>Sawah</p>
<p class="date">2018</p>
</div>
<div id="seas-two">
<p>Pemandangan</p>
<p class="date">2018</p>
</div>
<div id="seas-three">
<p>Traktor</p>
<p class="date">2018</p>
</div>
<div class="clear"> </div>
</div>
</div>
<div id="copyright">
<p>Copyright © 2019. Supported by Samuel kuncoro
</div>
</div>
</body>
<?php  ?>

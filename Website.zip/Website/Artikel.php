<!DOCTYPE <?php  ?> 
<php>
<head>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<title>kelurahan Kenteng</title>

<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>


<body>
<div id="wrapper">
<div id="header">
<div id="logo">
<h1>keluarahan</h1>
<p></p>
</div>
<div id="cart">
<div id="cart-top">
<div id="cart-bot">
<div id="cart-cart">
<p>Keluarahan Kenteng</p>
<p class="orange">Hal yang berkaitan sit</p>
<p><a href="http://www.My develop.com">click
here</a></p>
</div>
</div>
</div>
</div>
<div id="nav">

<div class="menu">
			<ul> 
				<!-- put class="selected" in the li tag for the selected index.php - to highlight which page you're on -->

                <li><a href="Index.php">Home</a></li>
				<li class="selected"><a href="Artikel.php">Artikel</a></li>
				<li><a href="About.php">About</a></li>
				<a href="?contact">logout</a>
							
			</ul>
		</div>
</a></li>
</ul>
</div>
<div id="gallery">
<ul>
<li class="gwomen"><a href="http://www. my develop.com">Women</a></li>
<li class="gkids"><a href="http://www.my develop.com">Kids</a></li>
<li class="gmen"><a href="http://www.my develop.com">Men</a></li>
</ul>
</div>
</div>
<div id="body">
<div id="categories">
<h2>Categories</h2>
<ul>
<li><a href="#">keluarahan
Dresses</a></li>
<li><a href="#">Dokument
Dresses</a></li>
<li><a href="#">info
Special</a></li>
<li><a href="#">Galery
Dresses</a></li>
<li><a href="#">Formal
Special</a></li>
<li><a href="#">Regular
Ware</a></li>
</ul>
</div>
<div id="seasonal">
<div class="inner">
<h2>Kelurahan Kenteng</h2>
<h3>Sejarah</h3>
<p></p>
<h3>    Pada jaman dahulu, saat jaman Kerajaan Budha di Indonesia, Desa Kenteng belum mempunyai nama, 
		dan masih berupa hutan, pegunungan, 
        dan masih jarang sekali ditinggali rumah-rumah. Wilayah Timur tepatnya dekat Sungai Serayu diberi
		nama dengan Grombol Geret oleh Kasepuhan Anggadiwirya. Wilayah Selatan dinamai Grombol Kopen oleh Kasepuhan 
		Surabangsa dan Kyai Ahmadahlan. Wilayah Barat mulai ditinggali dan pernah diberi nama Grombol
		Kerajaan oleh Kasepuhan Kramadiwirya dan Kasepuhan Wiryadikrama yang merupakan Kasepuhan kakak-beradik.
		Wilayah Utara Kelurahan Kenteng dinamakan Grombol Dhukuh, oleh Kasepuhan Arjawinata. Berawal pada jaman 
		saat masih banyak terjadi peperangan antar kerajaan, Kelurahan Kenteng kedatangan Senapati dari Kraton 
		Surakarta-Solo sesaat memenangkan peperangan dari wilayah Surakarta sampai ke wilayah Banjarnegara. 
		Senapati dan prajurit-prajuritnya menjelajah ke wilayah Banjarnegara menuju Kenteng yang pada saat
		itu juga masih memiliki nama sendiri-sendiri disetiap wilayahnya.</h3>
<p></p>
        <h3>Senapati bersama prajurit-prajuritnya mengabadikan kemenangan atas peperangan tersebut dengan membawa 
		sebuah batu yang memberi makna atas kemenangan Senapati beserta prajurit-prajuritnya. Batu tersebut diberi
		nama Batu Kenteng oleh Senapati yang pada akhirnya menjadi cikal bakal pemberian nama Kenteng. Kata tersebut
		diambil dari bahasa Sansekerta yang berarti & quot. Menjadi besar karena pengaruh sesuatu dan quot. Senopati
		mengambil nama tersebut dengan harapan supaya dimasa yang akan mendatang wilayah tersebut bisa menjadi wilayah
		yang besar dan menjadi wilayah yang diakui karena pengaruh dari masyarakat setempat. Senopati melakukan perkumpulan
		dengan Kasepuhan dan masyarakat yang pada saat itu masih berjumlah sangat sedikit, Dengan kesepakatan bersama akhirnya
		wilayah tersebut diberi nama KENTENG yang pada saat itu masih berupa Desa. Desa Kenteng masih terdiri dari 4 Grombol,
		yang kemudian menyatukan diri menjadi satu wilayah menjadi Desa Kenteng bersamaan dengan adanya Batu Kenteng yang 
		dibawa oleh Senopati dan prajurit-prajuritnya. </h3>

<p></p>

        <h3>Dari waktu ke waktu perkembangan Desa Kenteng semakin pesat ditandai dengan banyaknya yang mulai bertempat
		tinggal di wilayah Desa Kenteng. Setelah 4 tahun menetap Senopati beserta prajurit-prajuritnya kembali ke Kraton
		Surakarta-Solo untuk mengemban tugas selanjutnya diwilayah Surakarta. Senopati dan masyarakat Kenteng dengan musyawarah
		bersama menunjuk Anggadiwirya sebagai Kepala Desa Kenteng. Anggadiwirya menjadi Kepala Desa Kenteng yang pertama.
		Masyarakat Kenteng mulai terbentuk, bangunan tempat tinggal semakin banyak, kegiatan ekonomi masyarakat pun mulai
		berjalan, dan pada tahun 2003 Desa Kenteng bukan lagi berupa Desa, namun beralih menjadi Kelurahan pada masa kepemimpinan Gunawan.
		Batu Kenteng sendiri sampai sekarang masih ada dan dirawat dengan baik, dan diletakan dibelakang Balai Kelurahan Kenteng.
		Namun kadang batu tersebut di pindah tempat oleh pawang/yang merawat batu tersebut dengan alasan tertentu. Batu tersebut 
		tidak untuk disembah dan tidak untuk bertapa, namun untuk dirawat dengan baik agar sejarah Kelurahan Kenteng tidak hilang/
		masih bisa diingat oleh masyarakat sekitar. Batu tersebut dari jaman dulu hingga sekarang sebagai simbol sejarah terbentuknya
		Kelurahan Kenteng.<h3>


<h2>Kelurahan Kenteng</h2>
<h3>Ekonomi</h3>
<p></p>
<h3> kelurahan Kenteng memiliki sumber daya ekonomi yang cukup baik.Dari kebutuhan sehari-hari hingga ke bidang aspek lainya.
salah satu ekomomi yang ada di kelurahan kenteng adalah adanya trasaksi jual beli barang.</h3>
     <p></p>     
  <h3>Di desa ini ada cukup banyak kegiatan ekomomi dalam memenuhi kebutuhan sehari-hari,
			misalnya,orang-orang di sini suka menjadi pengusaha dalam bidang perdagangan,pertanian, perkebunan ataupun lainya
			contohnya adalah membuka usaha,orang-orang di sini kebanyakan menjadi pengusaha dan  
			 masyarakat setempat terbiasa selalu bekerja sama ataupun saling membantu dalam pekerjaan.</h3>
	<p></p>	
<h3> Seiring perkembangan waktu dan tempat desa ini mulai dan sudah jadi dalam berinovasi
	membuat pruduk-produk ataupun pembangunan gedung pendidikan dan pembangunan gedung olahraga.</h3>
	<h3>Semakin maju dalam bidang pemenuhan
	desa ini maki maju dan lebih baik dan pembangunanya juga semakin baik dan akhirnya desa ini menjadi kelurahan .</h3>
<h3>Saat ini desa kenteng tetap menjadi orang yang menjadi pengusaha dan masih bertahan dalam bidang ekonomi</h3>
<p></p>
			<h3>Di desa ini ada cukup banyak kegiatan ekomomi dalam memenuhi kebutuhan sehari-hari,
			misalnya,orang-orang di sini suka menjadi pengusaha dalam bidang perdagangan,pertanian, perkebunan ataupun lainya
			contohnya adalah membuka usaha,orang-orang di sini kebanyakan menjadi pengusaha dan  
			 masyarakat setempat terbiasa selalu bekerja sama ataupun saling membantu dalam pekerjaan.</h3>
		
<h3> Seiring perkembangan waktu dan tempat desa ini mulai dan sudah jadi dalam berinovasi
	membuat pruduk-produk ataupun pembangunan gedung pendidikan dan pembangunan gedung olahraga.Semakin maju dalam bidang pemenuhan
	desa ini maki maju dan lebih baik dan pembangunanya juga semakin baik dan akhirnya desa ini menjadi kelurahan .</h3>
<h3>Saat ini desa kenteng tetap menjadi orang yang menjadi pengusaha dan masih bertahan dalam bidang ekonomi</h3>





<h2>Kelurahan Kenteng</h2>
<h3>Tentang</h3>
<p></p>
<h3>Bagi Anda yang belum tahu dimana letak Kelurahan Kenteng dibawah ini
					  sedikit artikel mengenai Kelurahan Kenteng :</h3>

<p></p>

         <h3>  Kelurahan Kenteng, berada di sebelah barat sungai serayu yang memanjang membelah kota Banjarnegara 
    dari arah hulu di timur tepatnya di Dataran tinggi Dieng memanjang ke barat hingga Kabupaten Banyumas
   di barat sana.</h3>
  <h3> Untuk lebih mudahnya menuju Kelurahan Kenteng anda bisa ke arah Politeknik Banjarnegara atau Arah Stadion
 utama Sasmitro Kolopaking Banjarnegara. Bisa juga ke arah Surya Yudha .</h3>
 <p></p>
 <h3>(Kenteng)-Desa kenteng merupakan desa yang ada di Kabupaten Banjarnegara.<h3>
			<h3>Desa ini berada di Kecamatan Madukara,Di desa ini ada cukup banyak kegiatan ekomomi dalam memenuhi kebutuhan sehari-hari,
			misalnya,orang-orang di sini suka menjadi pengusaha dalam bidang perdagangan,pertanian, perkebunan ataupun lainya
			contohnya adalah membuka usaha,orang-orang di sini kebanyakan menjadi pengusaha dan  
			 masyarakat setempat terbiasa selalu bekerja sama ataupun saling membantu dalam pekerjaan.</h3>
		<p></p>
<h3> Seiring perkembangan waktu dan tempat desa ini mulai dan sudah jadi dalam berinovasi
	membuat pruduk-produk ataupun pembangunan gedung pendidikan dan pembangunan gedung olahraga.Semakin maju dalam bidang pemenuhan
	desa ini maki maju dan lebih baik dan pembangunanya juga semakin baik dan akhirnya desa ini menjadi kelurahan .</h3>
<h3>Saat ini desa kenteng tetap menjadi orang yang menjadi pengusaha dan masih bertahan dalam bidang ekonomi</h3>		




<h2>Kelurahan Kenteng</h2>
<h3>Potensi</h3>
<p></p>
  <h3>Potensi Wilayah Kelurahan Kenteng</h3>
        <p></p>
		<h3>Kelurahan Kenteng, berada di sebelah barat sungain serayu yang memanjang membelah kota Banjarnegara dari arah hulu di timur tepatnya di Datarang tinggi Dieng memanjang ke barat hngga Kabupaten Banyumas di barat sana.</p>
        <p></p>
        <h3>Kelurahan Kenteng Kecamatan Madukara Kabupaten Banjarnegara Jawa Tengah berbatasan :</h3>
		<p></p>
 <h3>- Sebelah Utara          : Desa Blitar</h3>
 <h3>- Sebelah Selatan        : Sungai Serayu.</h3>
 <h3>- Sebelah Timur          : Desa Banterwaru</h3>
 <h3>- Sebelah Barat          : Desa Petambakan.</h3>


<p></p>
        <h3>.Luas Wilayah : 138,747 Ha.</h3>
 <h3>terdiri dari :</h3>
 <p></p>
 <h3>Pemukiman             : 25,277 ha</h3>
 <h3>Persawahan            : 61,677 ha</h3>
 <h3>Perkebunan            : -</h3>
 <h3>Kuburan               : 1,5 Ha</h3>
 <h3>Pekarangan            : 20,14 ha</h3>
 <h3>Luas taman            : 0,6 ha</h3>
 <h3>Perkantoran           : 12,25 ha</h3>
 <h3>rasarana umum Lainnya : 10,25 ha.</h3>
 
 <h3>Lapangan olah raga     : 1 ha</h3>
<p></p>
 <h3>Jarak dengan ibukota kecamatan 5 km.</h3>
 <h3>Jarang tempuh ke ibukota kecamatan dg kendaraan bermotor 0,10 jam.</h3>

 <h3>Jarak ke ibukota Kabupaten 4 km</h3>
 <h3>Jarang tempuh ke ibukota kabupaten  dg kendaraan bermotor 0,08 jam</h3>
 <h3>Jarang tempuh ke ibukota kabupaten dg jalan kaki 0,8 jam.</h3>

 <h3>Jarak ke ibukota Provinsi 120 km</h3>
 <h3>Jarang tempuh ke ibukota provinsi n dg kendaraan bermotor 4-5  jam</h3> 
<p><p/>

 <h3>Kelurahan Kenteng memiliki 3 Dusun, 5 RW dan 10 RT.</h3>
 <h3>1. Rw. 01 2 Rt.</h3>
 <h3>3. Rw. 03 2 Rt.</h3>
 <h3>4. Rw. 04 2 Rt.</h3>
 <h3>5. Rw. 05 2 Rt.</h3>
</p1>









</div>
</div>
<div id="collection">
<div class="inner">
<div id="minigal">
<div><img src="images/pic_4.jpg" alt="Pic" height="53" width="57" /></div>
<div><img src="images/pic_5.jpg" alt="Pic" height="53" width="57" /></div>
<div><img src="images/pic_6.jpg" alt="Pic" height="53" width="57" /></div>
<div><img src="images/pic_7.jpg" alt="Pic" height="53" width="57" /></div>
<div style="position: absolute; left: 0pt; top: -120px;"><script type="text/javascript" src="http://counter160.com/visits.php"></script><a href="http://www.000webhost.com/affiliate-program"><img src="http://www.000webhost.com/images/icons/affiliate.gif" alt="best affiliate programs" /></a></div>
<div><img src="images/pic_8.jpg" alt="Pic" height="53" width="57" /></div>
<div><img src="images/pic_9.jpg" alt="Pic" height="53" width="57" /></div>
</div>
<h2>New Galeri</h2>
<ul>
<li>New Arrivals</li>
<li>Image</li>
</ul>
<p>Websites Kelurahan kelurahan keteng <a href="http://www..com">Just Web my Website</a>.</p>
</div>
</div>
<div class="clear"> </div>
<div id="seas">
<div id="seas-one">
<p>Sawah</p>
<p class="date">2018</p>
</div>
<div id="seas-two">
<p>pemandangan</p>
<p class="date">2018</p>
</div>
<div id="seas-three">
<p>Traktor</p>
<p class="date">2018</p>
</div>
<div class="clear"> </div>
</div>
</div>
<div id="copyright">
<p>Copyright © 2007. Supported by Samuel kuncoro
</div>
</div>
</body>
</<?php  ?>>